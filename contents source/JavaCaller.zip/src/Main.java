/**
 *	Project: Blick
 *	Content: Eye-alarm(Caller)
 *	Date: 07/12/2004
 *	Author: Seung-wook KIM
 */

public class Main
{
	public static void main(String args[])
	{
		new Frame();
		
	}
}